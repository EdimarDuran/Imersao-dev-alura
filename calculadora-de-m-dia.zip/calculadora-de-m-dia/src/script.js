var nome = "Edimar"
var notadoprimeirobimestre = 9.5454
var notadosegundobimestre = 9
var notadoterceirobimestre = 9
var notadoquartobimestre = 9

var notafinal = (notadoprimeirobimestre + notadosegundobimestre + notadoterceirobimestre + notadoquartobimestre)/4

var notafixa = notafinal.toFixed(2)
console.log("Bem vindo " + nome)
console.log(notafixa)